# todo make this cache things


class Cache(object):

    def __init__(self):
        self.cache = {}

    def clear_cache(self):
        self.cache = {}

    def retrieve_asset(self):
        pass

    def get_instance(self, service):
        pass



