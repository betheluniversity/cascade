__author__ = 'ejc84332'


class NoSuchTypeException(Exception):
    pass